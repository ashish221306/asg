$(function(){
      $('.count-num').rCounter({
        duration: 40
      });
    });